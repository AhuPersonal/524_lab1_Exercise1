from distutils.core import setup

setup(
    name='524_lab1_Exercise1',
    version='0.1dev',
	author='Ahu ORAL',
	author_email='ahupersembe@gmail.com',
    packages=['ahupythonpackage',],
	url='https://github.com/AhuPersonal/524_lab1_Exercise1',
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read(),
)